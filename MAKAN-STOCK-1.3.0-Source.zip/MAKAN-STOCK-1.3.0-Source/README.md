# MAKAN STOCK 1.3.0

Inventory and warehouse management by **Makan / MAKAN LAB**. Persian and English, RTL/LTR, responsive UI, light/dark themes, simple/pro modes. Original application source: **MIT**.

- Website: https://makanlab.tech/
- Public contact: makan20042002@gmail.com
- User manual: `docs/MAKAN-STOCK-Guide-fa.pdf` (Persian, bundled offline)
- Feature status: `docs/FEATURES.csv` and in-app roadmap

## Windows downloads

1. **Setup EXE:** per-user installation, Start menu/Desktop shortcuts, uninstaller; Windows 10/11 x64. No separate Node installation. The final page offers to open the Persian manual by default.
2. **Portable ZIP:** extract completely to a writable folder, run `MAKAN-STOCK.exe`. Stop with `Stop-AnbarOne.cmd`. Keep the entire folder.
3. **Source ZIP:** application, licensed bundled frontend libraries, tests, docs and Windows installer source. Runtime binaries and customer data are excluded.

The first launch asks you to create the owner account. There are no shipped credentials or customer databases. Demo data is optional. Installed data lives in `%LOCALAPPDATA%\AnbarOne\data`; portable data lives beside the executable in `data`. The legacy directory/API identifiers remain for compatibility. Closing the browser does not stop the background local server.

## Capabilities

Catalog, categories, brands, units/conversions, variants, images, custom fields, pricing/currency; warehouses/locations; stock layers and movements; FIFO/FEFO, serial/lot/expiry, quarantine; reorder rules; counted stock with independent recount/approval; transfers and in-transit receipts; suppliers, purchase requests/approvals, quotes, orders, partial receipts and returns; customers, sales/backorders/reservations, scanned picking, per-package contents/weights, partial dispatch and inspected returns; reports, CSV/XLSX, scheduled disk reports; alerts/reminders; users/custom roles, granular fulfillment capabilities and warehouse scope; audit verification; backups/restore; API keys and signed webhook outbox; limited offline queue and PWA/mobile UI.

## Honest boundaries

This is a single-process Node/SQLite application suitable for evaluation by small/medium businesses, not a certified enterprise WMS. No seat-license limit is enforced, but no concurrent-user capacity guarantee or enterprise load validation is provided. Default access is local only; multi-device operation requires separately configured trusted HTTPS networking. Native mobile apps, SSO/MFA, multi-company, carrier/email connectors, statistical forecasting/AI, kits/manufacturing, spatial route optimization and general workflow automation are not complete. Offline writes cover four operations and stop on conflicts. See the full feature matrix for partial support. Accounting, ledger, tax and Iranian tax-system integration are deliberately excluded.

## Run from source

Install official Node.js >=22.13 with node:sqlite support (release tested on 22.23.2). No npm dependencies are required for the server.

```sh
npm start
npm test
npm run check
```

On Windows, `npm start` launches the local service and opens the default browser. On other operating systems run `node src/server.mjs` and open its printed loopback URL manually. The Windows launcher/browser-opening integration is Windows-specific. `ANBAR_DATA` selects an isolated server data directory for testing. Never put a live database in the public repository.

## Build Windows release

Place the official Node x64 runtime and its license at `runtime/node.exe` and `runtime/NODE-LICENSE.txt`. Use a Windows .NET Framework C# compiler and official Inno Setup 6.7+. Run:

```powershell
./scripts/build-windows.ps1 -InnoCompiler 'C:/path/to/ISCC.exe'
```

The existing PDF and icon assets are included. Manual source is `docs/Manual-fa.md`. The installer is unsigned; commercial code signing requires the publisher's own certificate. Setup does not open firewall ports or configure TLS. Installation/upgrade preserves existing data; uninstall preserves user-generated data.

## Publishing and licenses

Upload the Setup, Portable and Source files with the Persian PDF and SHA256SUMS.txt. No GitHub repository or website upload is performed by this package. Review the feature-status documentation before advertising capabilities. Preserve LICENSE and THIRD-PARTY-NOTICES.txt when redistributing. Node, SheetJS, JsBarcode, QRCode and Vazirmatn have their own included licenses. Build tools are not bundled with the client app.
